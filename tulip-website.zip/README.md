# 🌷 Tulip Website

Website sederhana bertema bunga tulip.

## Fitur
- Informasi tentang tulip
- Makna warna tulip
- Desain minimalis

## Cara Menjalankan
Buka file `index.html` di browser.

## Author
Gudhal Production
